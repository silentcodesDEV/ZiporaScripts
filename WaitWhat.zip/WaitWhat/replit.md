# Zipora - Ferramentas Educacionais

## Overview

Zipora is a Brazilian educational tools discovery platform built as a single-page web application with authentication system. The project provides an interactive interface for users to search and explore educational tools with real-time filtering capabilities, multiple theme support (dark as default), and a responsive design optimized for Brazilian users.

## User Preferences

Preferred communication style: Simple, everyday language.
Website name: Zipora (changed from "Ferramentas Educacionais BR")
Default theme: Dark theme (changed from light theme)
Storage preference: File-based storage using users.txt instead of database
Theme expansion: Multiple theme varieties with animations and accessibility options

## System Architecture

### Frontend Architecture
- **Single Page Application (SPA)**: Pure vanilla JavaScript implementation without frameworks
- **Component-based Structure**: Modular JavaScript classes for theme management and application state
- **Responsive Design**: Mobile-first approach with CSS Grid and Flexbox layouts
- **Progressive Enhancement**: Core functionality works without JavaScript, enhanced with interactive features

### Backend Architecture
- **Express.js Server**: RESTful API server for authentication and data management
- **PostgreSQL Database**: Persistent storage for users, sessions, and tool access logs
- **Drizzle ORM**: Type-safe database operations with automatic fallback to memory storage
- **Session Management**: Secure token-based authentication with automatic cleanup

### State Management
- **Centralized State**: `AppState` object manages application-wide data including current theme, tools list, filtered results, and loading states
- **DOM Abstraction**: `DOM` object centralizes all element references for better maintainability
- **Local Storage Integration**: Persists user preferences like theme selection across browser sessions

## Key Components

### Theme System
- **Multi-theme Support**: Eight distinct themes (light, dark, cloudy, ocean, forest, purple, sunset, rose) with CSS custom properties
- **Advanced Settings System**: Comprehensive configuration modal with theme selection, animations, and accessibility options
- **Theme Manager Class**: Handles theme switching, persistence, and UI updates
- **Dynamic CSS Variables**: Seamless theme transitions using CSS custom properties
- **Animation Controls**: Toggleable animations with accessibility considerations

### Search and Filtering
- **Real-time Search**: Instant filtering as users type in the search input
- **Case-insensitive Matching**: Robust search functionality that matches tool names and descriptions
- **Clear Search Functionality**: Easy reset of search terms with visual feedback

### User Interface
- **Card-based Layout**: Tools displayed in responsive grid cards with hover effects
- **Loading States**: Visual feedback during data loading operations
- **Toast Notifications**: User feedback system for actions and errors
- **Accessibility Features**: Keyboard navigation, ARIA labels, and semantic HTML

## Data Flow

1. **Initialization**: App loads and initializes DOM references and theme system
2. **Data Loading**: Tools data is loaded (currently prepared for external API integration)
3. **State Updates**: User interactions update centralized state
4. **UI Rendering**: State changes trigger re-rendering of affected UI components
5. **Persistence**: Theme preferences and other settings saved to localStorage

## External Dependencies

### CDN Resources
- **Font Awesome 6.0.0**: Icon library for UI elements and visual indicators
- **Google Fonts (Inter)**: Typography system for consistent text rendering
- **Base64 Favicon**: Embedded favicon for branding

### Node.js Dependencies
- **Express.js**: Web server framework for API endpoints
- **Drizzle ORM**: TypeScript-first ORM for PostgreSQL database operations
- **@neondatabase/serverless**: PostgreSQL client for serverless environments
- **CORS**: Cross-origin resource sharing middleware
- **dotenv**: Environment variable management

### Database
- **PostgreSQL**: Primary database for persistent storage
- **Tables**: users, user_sessions, tool_access_logs with proper relations and indexes

### Browser APIs
- **Fetch API**: For communication with backend APIs
- **localStorage**: Fallback for client-side data persistence
- **DOM APIs**: For dynamic content manipulation and event handling
- **CSS Custom Properties**: For theme system implementation

## Deployment Strategy

### Static Hosting Ready
- **No Build Process**: Direct deployment of HTML, CSS, and JavaScript files
- **CDN Optimized**: External resources loaded from CDNs for performance
- **Progressive Enhancement**: Core functionality works in all modern browsers

### Performance Considerations
- **Lightweight Bundle**: Minimal JavaScript footprint with no framework dependencies
- **CSS Optimization**: Efficient use of custom properties for theme switching
- **Lazy Loading Ready**: Structure prepared for future image and content lazy loading

### Browser Compatibility
- **Modern Browser Support**: ES6+ features used with graceful degradation
- **Responsive Design**: Mobile-first approach ensuring cross-device compatibility
- **Accessibility Compliance**: Semantic HTML and ARIA attributes for screen readers

The architecture prioritizes simplicity, performance, and user experience while maintaining extensibility for future enhancements such as backend integration, user accounts, and advanced filtering capabilities.