const { Pool, neonConfig } = require('@neondatabase/serverless');
const { drizzle } = require('drizzle-orm/neon-serverless');
const { eq, and, gt } = require('drizzle-orm');
const { pgTable, text, timestamp, boolean, serial } = require('drizzle-orm/pg-core');
const crypto = require('crypto');
const ws = require('ws');

// Configure neon
neonConfig.webSocketConstructor = ws;

// Define schema for JavaScript
const users = pgTable('users', {
  id: serial('id').primaryKey(),
  ra: text('ra').notNull().unique(),
  password: text('password').notNull(),
  created_at: timestamp('created_at').defaultNow().notNull(),
  last_login_at: timestamp('last_login_at'),
  is_active: boolean('is_active').default(true).notNull(),
  terms_accepted: boolean('terms_accepted').default(false).notNull(),
  terms_accepted_at: timestamp('terms_accepted_at'),
});

const userSessions = pgTable('user_sessions', {
  id: serial('id').primaryKey(),
  user_id: serial('user_id').references(() => users.id).notNull(),
  session_token: text('session_token').notNull().unique(),
  expires_at: timestamp('expires_at').notNull(),
  created_at: timestamp('created_at').defaultNow().notNull(),
  ip_address: text('ip_address'),
  user_agent: text('user_agent'),
});

const toolAccessLogs = pgTable('tool_access_logs', {
  id: serial('id').primaryKey(),
  user_id: serial('user_id').references(() => users.id).notNull(),
  tool_name: text('tool_name').notNull(),
  tool_url: text('tool_url').notNull(),
  accessed_at: timestamp('accessed_at').defaultNow().notNull(),
  ip_address: text('ip_address'),
});

class DatabaseStorage {
  constructor() {
    if (!process.env.DATABASE_URL) {
      throw new Error("DATABASE_URL must be set. Did you forget to provision a database?");
    }
    
    this.pool = new Pool({ connectionString: process.env.DATABASE_URL });
    this.db = drizzle({ client: this.pool, schema: { users, userSessions, toolAccessLogs } });
  }

  async getUser(id) {
    const [user] = await this.db.select().from(users).where(eq(users.id, id));
    return user || undefined;
  }

  async getUserByRA(ra) {
    const [user] = await this.db.select().from(users).where(eq(users.ra, ra));
    return user || undefined;
  }

  async createUser(insertUser) {
    const [user] = await this.db
      .insert(users)
      .values({
        ra: insertUser.ra,
        password: insertUser.password,
        created_at: new Date(),
        is_active: insertUser.is_active ?? true,
        terms_accepted: insertUser.terms_accepted ?? false,
        terms_accepted_at: insertUser.terms_accepted ? new Date() : null,
      })
      .returning();
    return user;
  }

  async updateUser(id, updates) {
    const [user] = await this.db
      .update(users)
      .set(updates)
      .where(eq(users.id, id))
      .returning();
    return user || undefined;
  }

  async createSession(userId, ipAddress, userAgent) {
    const sessionToken = crypto.randomBytes(32).toString('hex');
    const expiresAt = new Date();
    expiresAt.setDate(expiresAt.getDate() + 7);

    console.log(`Creating session for user ID: ${userId}`);
    
    try {
      const [session] = await this.db
        .insert(userSessions)
        .values({
          user_id: userId,
          session_token: sessionToken,
          expires_at: expiresAt,
          created_at: new Date(),
          ip_address: ipAddress || null,
          user_agent: userAgent || null,
        })
        .returning();

      console.log(`Session created successfully: ${sessionToken.substring(0, 8)}...`);
      return session;
    } catch (error) {
      console.error('Database session creation error:', error);
      throw error;
    }
  }

  async getValidSession(sessionToken) {
    const [session] = await this.db
      .select()
      .from(userSessions)
      .where(
        and(
          eq(userSessions.session_token, sessionToken),
          gt(userSessions.expires_at, new Date())
        )
      );
    
    return session || undefined;
  }

  async deleteSession(sessionToken) {
    await this.db
      .delete(userSessions)
      .where(eq(userSessions.session_token, sessionToken));
  }

  async deleteExpiredSessions() {
    await this.db
      .delete(userSessions)
      .where(gt(new Date(), userSessions.expires_at));
  }

  async logToolAccess(userId, toolName, toolUrl, ipAddress) {
    const [log] = await this.db
      .insert(toolAccessLogs)
      .values({
        user_id: userId,
        tool_name: toolName,
        tool_url: toolUrl,
        accessed_at: new Date(),
        ip_address: ipAddress,
      })
      .returning();

    return log;
  }

  async getUserToolAccess(userId, limit = 50) {
    return await this.db
      .select()
      .from(toolAccessLogs)
      .where(eq(toolAccessLogs.user_id, userId))
      .orderBy(toolAccessLogs.accessed_at)
      .limit(limit);
  }
}

class MemStorage {
  constructor() {
    this.users = new Map();
    this.sessions = new Map();
    this.toolLogs = [];
    this.nextUserId = 1;
    this.nextSessionId = 1;
    this.nextLogId = 1;
  }

  async getUser(id) {
    return this.users.get(id);
  }

  async getUserByRA(ra) {
    for (const user of this.users.values()) {
      if (user.ra === ra) return user;
    }
    return undefined;
  }

  async createUser(insertUser) {
    const user = {
      id: this.nextUserId++,
      ...insertUser,
      created_at: new Date(),
      last_login_at: null,
      is_active: insertUser.is_active ?? true,
      terms_accepted: insertUser.terms_accepted ?? false,
      terms_accepted_at: insertUser.terms_accepted ? new Date() : null,
    };
    this.users.set(user.id, user);
    return user;
  }

  async updateUser(id, updates) {
    const user = this.users.get(id);
    if (!user) return undefined;
    
    const updatedUser = { ...user, ...updates };
    this.users.set(id, updatedUser);
    return updatedUser;
  }

  async createSession(userId, ipAddress, userAgent) {
    const sessionToken = crypto.randomBytes(32).toString('hex');
    const expiresAt = new Date();
    expiresAt.setDate(expiresAt.getDate() + 7);

    const session = {
      id: this.nextSessionId++,
      user_id: userId,
      session_token: sessionToken,
      expires_at: expiresAt,
      created_at: new Date(),
      ip_address: ipAddress || null,
      user_agent: userAgent || null,
    };

    this.sessions.set(sessionToken, session);
    return session;
  }

  async getValidSession(sessionToken) {
    const session = this.sessions.get(sessionToken);
    if (!session || session.expires_at < new Date()) {
      this.sessions.delete(sessionToken);
      return undefined;
    }
    return session;
  }

  async deleteSession(sessionToken) {
    this.sessions.delete(sessionToken);
  }

  async deleteExpiredSessions() {
    const now = new Date();
    for (const [token, session] of this.sessions.entries()) {
      if (session.expires_at < now) {
        this.sessions.delete(token);
      }
    }
  }

  async logToolAccess(userId, toolName, toolUrl, ipAddress) {
    const log = {
      id: this.nextLogId++,
      user_id: userId,
      tool_name: toolName,
      tool_url: toolUrl,
      accessed_at: new Date(),
      ip_address: ipAddress || null,
    };

    this.toolLogs.push(log);
    return log;
  }

  async getUserToolAccess(userId, limit = 50) {
    return this.toolLogs
      .filter(log => log.user_id === userId)
      .sort((a, b) => b.accessed_at.getTime() - a.accessed_at.getTime())
      .slice(0, limit);
  }
}

// Create storage instance
const storage = (() => {
  try {
    return new DatabaseStorage();
  } catch (error) {
    console.warn('Database not available, using memory storage:', error.message);
    return new MemStorage();
  }
})();

module.exports = { storage };