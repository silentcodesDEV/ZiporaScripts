const express = require('express');
const cors = require('cors');
const path = require('path');
require('dotenv').config();

const app = express();
const PORT = process.env.PORT || 5000;

// Middleware
app.use(cors());
app.use(express.json());
app.use(express.static(path.join(__dirname, '..')));

// Import file storage
let storage;
try {
  const { FileStorage } = require('./fileStorage.js');
  storage = new FileStorage();
  console.log('✅ File storage loaded successfully');
} catch (error) {
  console.warn('Could not load file storage:', error.message);
  storage = null;
}

// Authentication routes
app.post('/api/auth/login', async (req, res) => {
  try {
    const { ra, password, termsAccepted } = req.body;

    if (!ra || !password) {
      return res.status(400).json({ error: 'RA e senha são obrigatórios' });
    }

    let user = await storage.getUserByRA(ra);

    if (!user) {
      // Create new user if doesn't exist
      const hashedPassword = await bcrypt.hash(password, 10);

      try {
        user = await storage.createUser({
          ra,
          password: hashedPassword,
          is_active: true,
          terms_accepted: !!termsAccepted,
        });
        console.log(`✅ New user created: ${ra}`);
      } catch (createError) {
        console.error('Error creating user:', createError);
        return res.status(500).json({ error: 'Erro ao criar usuário' });
      }
    } else {
      // Verify password for existing user
      const isValidPassword = await bcrypt.compare(password, user.password);
      if (!isValidPassword) {
        return res.status(401).json({ error: 'Credenciais inválidas' });
      }

      // Update terms acceptance if needed
      if (termsAccepted && !user.terms_accepted) {
        try {
          await storage.updateUser(user.id, {
            terms_accepted: true,
            terms_accepted_at: new Date(),
          });
          console.log(`✅ Terms accepted for user: ${ra}`);
        } catch (updateError) {
          console.error('Error updating user terms:', updateError);
        }
      }
    }

    // Create session
    let session;
    try {
      session = await storage.createSession(user.id, req.ip, req.get('user-agent'));
      console.log(`✅ Session created for user: ${ra}`);
    } catch (sessionError) {
      console.error('Error creating session:', sessionError);
      return res.status(500).json({ error: 'Erro ao criar sessão' });
    }

    // Update last login
    try {
      await storage.updateUser(user.id, { last_login_at: new Date() });
    } catch (loginUpdateError) {
      console.error('Error updating last login:', loginUpdateError);
    }

    res.json({
      success: true,
      user: {
        id: user.id,
        ra: user.ra,
        termsAccepted: user.terms_accepted,
      },
      sessionToken: session.session_token,
    });
  } catch (error) {
    console.error('Login error:', error);
    res.status(500).json({ error: 'Erro interno do servidor' });
  }
});

app.post('/api/auth/logout', async (req, res) => {
  try {
    const { sessionToken } = req.body;

    if (storage && sessionToken) {
      try {
        await storage.deleteSession(sessionToken);
      } catch (dbError) {
        console.error('Database error during logout:', dbError);
      }
    }

    res.json({ success: true });
  } catch (error) {
    console.error('Logout error:', error);
    res.status(500).json({ error: 'Erro interno do servidor' });
  }
});

app.post('/api/auth/validate', async (req, res) => {
  try {
    const { sessionToken } = req.body;

    if (!sessionToken) {
      return res.status(401).json({ error: 'Token de sessão obrigatório' });
    }

    if (storage) {
      try {
        const session = await storage.getValidSession(sessionToken);
        if (session) {
          const user = await storage.getUserByRA(session.userRA);
          return res.json({
            valid: true,
            user: user ? {
              ra: user.ra,
              createdAt: user.createdAt,
              lastLogin: user.lastLogin,
            } : null,
          });
        }
      } catch (dbError) {
        console.error('Database error during validation:', dbError);
      }
    }

    // If no valid session found or database error
    res.status(401).json({ valid: false });
  } catch (error) {
    console.error('Validation error:', error);
    res.status(500).json({ error: 'Erro interno do servidor' });
  }
});

// Debug route to check stored users (remove in production)
app.get('/api/debug/users', async (req, res) => {
  try {
    // This is for debugging - in production you should remove this route
    console.log('Debug: Checking stored users...');
    res.json({ message: 'Check server console for user data' });
  } catch (error) {
    console.error('Debug error:', error);
    res.status(500).json({ error: 'Debug error' });
  }
});

// Tool access logging
app.post('/api/tools/access', async (req, res) => {
  try {
    const { sessionToken, toolName, toolUrl } = req.body;

    if (storage && sessionToken) {
      try {
        const session = await storage.getValidSession(sessionToken);
        if (session) {
          await storage.logToolAccess(
            session.userRA,
            toolName,
            toolUrl,
            req.ip
          );
          return res.json({ success: true });
        }
      } catch (dbError) {
        console.error('Database error during tool access logging:', dbError);
      }
    }

    // Always return success even if logging fails
    res.json({ success: true });
  } catch (error) {
    console.error('Tool access logging error:', error);
    res.json({ success: true }); // Don't fail the user experience
  }
});

// Serve the main app
app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, '..', 'index.html'));
});

// Health check endpoint
app.get('/api/health', (req, res) => {
  res.json({ 
    status: 'ok', 
    timestamp: new Date().toISOString(),
    database: storage ? 'connected' : 'fallback',
  });
});

// Clean up expired sessions periodically (every hour)
if (storage) {
  setInterval(async () => {
    try {
      await storage.cleanExpiredSessions();
      console.log('Cleaned up expired sessions');
    } catch (error) {
      console.error('Error cleaning up sessions:', error);
    }
  }, 60 * 60 * 1000); // 1 hour
}

app.listen(PORT, '0.0.0.0', () => {
  console.log(`🚀 Zipora server running on http://0.0.0.0:${PORT}`);
  console.log(`Database: ${storage ? 'Connected' : 'Using fallback'}`);
});