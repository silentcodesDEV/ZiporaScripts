const fs = require('fs').promises;
const path = require('path');
const crypto = require('crypto');

class FileStorage {
    constructor() {
        this.usersFile = path.join(__dirname, '..', 'users.txt');
        this.sessionsFile = path.join(__dirname, '..', 'sessions.txt');
        this.logsFile = path.join(__dirname, '..', 'access_logs.txt');
    }

    async ensureFiles() {
        try {
            await fs.access(this.usersFile);
        } catch {
            await fs.writeFile(this.usersFile, '# Arquivo de usuários do Zipora\n# Formato: ra|senha|data_cadastro|ultimo_login|termos_aceitos\n');
        }

        try {
            await fs.access(this.sessionsFile);
        } catch {
            await fs.writeFile(this.sessionsFile, '# Sessões ativas\n# Formato: token|user_ra|expires_at|created_at|ip|user_agent\n');
        }

        try {
            await fs.access(this.logsFile);
        } catch {
            await fs.writeFile(this.logsFile, '# Logs de acesso às ferramentas\n# Formato: user_ra|tool_name|tool_url|accessed_at|ip\n');
        }
    }

    async getUserByRA(ra) {
        await this.ensureFiles();
        try {
            const content = await fs.readFile(this.usersFile, 'utf8');
            const lines = content.split('\n').filter(line => line && !line.startsWith('#'));
            
            for (const line of lines) {
                const [userRA, password, createdAt, lastLogin, termsAccepted] = line.split('|');
                if (userRA === ra) {
                    return {
                        ra: userRA,
                        password,
                        createdAt: new Date(createdAt),
                        lastLogin: lastLogin ? new Date(lastLogin) : null,
                        termsAccepted: termsAccepted === 'true'
                    };
                }
            }
        } catch (error) {
            console.error('Error reading users file:', error);
        }
        return null;
    }

    async createUser(ra, password, termsAccepted = true) {
        await this.ensureFiles();
        try {
            const now = new Date().toISOString();
            const userLine = `${ra}|${password}|${now}|${now}|${termsAccepted}\n`;
            await fs.appendFile(this.usersFile, userLine);
            
            return {
                ra,
                password,
                createdAt: new Date(now),
                lastLogin: new Date(now),
                termsAccepted
            };
        } catch (error) {
            console.error('Error creating user:', error);
            throw error;
        }
    }

    async updateUserLogin(ra) {
        await this.ensureFiles();
        try {
            const content = await fs.readFile(this.usersFile, 'utf8');
            const lines = content.split('\n');
            
            for (let i = 0; i < lines.length; i++) {
                if (lines[i].startsWith(ra + '|')) {
                    const parts = lines[i].split('|');
                    parts[3] = new Date().toISOString(); // Update last login
                    parts[4] = 'true'; // Ensure terms accepted
                    lines[i] = parts.join('|');
                    break;
                }
            }
            
            await fs.writeFile(this.usersFile, lines.join('\n'));
        } catch (error) {
            console.error('Error updating user login:', error);
        }
    }

    async createSession(userRA, ipAddress, userAgent) {
        await this.ensureFiles();
        try {
            const sessionToken = crypto.randomBytes(32).toString('hex');
            const expiresAt = new Date();
            expiresAt.setDate(expiresAt.getDate() + 7);
            
            const sessionLine = `${sessionToken}|${userRA}|${expiresAt.toISOString()}|${new Date().toISOString()}|${ipAddress || ''}|${userAgent || ''}\n`;
            await fs.appendFile(this.sessionsFile, sessionLine);
            
            return {
                sessionToken,
                userRA,
                expiresAt,
                createdAt: new Date(),
                ipAddress,
                userAgent
            };
        } catch (error) {
            console.error('Error creating session:', error);
            throw error;
        }
    }

    async getValidSession(sessionToken) {
        await this.ensureFiles();
        try {
            const content = await fs.readFile(this.sessionsFile, 'utf8');
            const lines = content.split('\n').filter(line => line && !line.startsWith('#'));
            
            for (const line of lines) {
                const [token, userRA, expiresAt, createdAt, ipAddress, userAgent] = line.split('|');
                if (token === sessionToken && new Date(expiresAt) > new Date()) {
                    return {
                        sessionToken: token,
                        userRA,
                        expiresAt: new Date(expiresAt),
                        createdAt: new Date(createdAt),
                        ipAddress,
                        userAgent
                    };
                }
            }
        } catch (error) {
            console.error('Error reading sessions file:', error);
        }
        return null;
    }

    async deleteSession(sessionToken) {
        await this.ensureFiles();
        try {
            const content = await fs.readFile(this.sessionsFile, 'utf8');
            const lines = content.split('\n');
            const filteredLines = lines.filter(line => !line.startsWith(sessionToken + '|'));
            await fs.writeFile(this.sessionsFile, filteredLines.join('\n'));
        } catch (error) {
            console.error('Error deleting session:', error);
        }
    }

    async cleanExpiredSessions() {
        await this.ensureFiles();
        try {
            const content = await fs.readFile(this.sessionsFile, 'utf8');
            const lines = content.split('\n');
            const now = new Date();
            
            const validLines = lines.filter(line => {
                if (!line || line.startsWith('#')) return true;
                const parts = line.split('|');
                if (parts.length < 3) return true;
                return new Date(parts[2]) > now;
            });
            
            await fs.writeFile(this.sessionsFile, validLines.join('\n'));
        } catch (error) {
            console.error('Error cleaning expired sessions:', error);
        }
    }

    async logToolAccess(userRA, toolName, toolUrl, ipAddress) {
        await this.ensureFiles();
        try {
            const logLine = `${userRA}|${toolName}|${toolUrl}|${new Date().toISOString()}|${ipAddress || ''}\n`;
            await fs.appendFile(this.logsFile, logLine);
        } catch (error) {
            console.error('Error logging tool access:', error);
        }
    }
}

module.exports = { FileStorage };