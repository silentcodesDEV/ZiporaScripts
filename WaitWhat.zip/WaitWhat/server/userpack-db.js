
const { Pool, neonConfig } = require('@neondatabase/serverless');
const { drizzle } = require('drizzle-orm/neon-serverless');
const ws = require('ws');

// Configure neon
neonConfig.webSocketConstructor = ws;

// Get the base DATABASE_URL and modify it to connect to userpack database
const baseUrl = process.env.DATABASE_URL;
if (!baseUrl) {
  throw new Error("DATABASE_URL must be set");
}

// Replace the database name in the URL to connect to userpack
const userpackUrl = baseUrl.replace(/\/[^\/]*$/, '/userpack');

const userpackPool = new Pool({ connectionString: userpackUrl });
const userpackDb = drizzle({ client: userpackPool });

module.exports = { userpackDb, userpackPool };
