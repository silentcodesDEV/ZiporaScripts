import { users, userSessions, toolAccessLogs, type User, type InsertUser, type UserSession, type InsertUserSession, type ToolAccessLog, type InsertToolAccessLog } from "../shared/schema";
import { db } from "./db";
import { eq, and, gt } from "drizzle-orm";
import crypto from 'crypto';

// Interface for storage operations
export interface IStorage {
  // User operations
  getUser(id: number): Promise<User | undefined>;
  getUserByRA(ra: string): Promise<User | undefined>;
  createUser(insertUser: InsertUser): Promise<User>;
  updateUser(id: number, updates: Partial<User>): Promise<User | undefined>;
  
  // Authentication operations
  createSession(userId: number, ipAddress?: string, userAgent?: string): Promise<UserSession>;
  getValidSession(sessionToken: string): Promise<UserSession | undefined>;
  deleteSession(sessionToken: string): Promise<void>;
  deleteExpiredSessions(): Promise<void>;
  
  // Tool access logging
  logToolAccess(userId: number, toolName: string, toolUrl: string, ipAddress?: string): Promise<ToolAccessLog>;
  getUserToolAccess(userId: number, limit?: number): Promise<ToolAccessLog[]>;
}

export class DatabaseStorage implements IStorage {
  // User operations
  async getUser(id: number): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user || undefined;
  }

  async getUserByRA(ra: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.ra, ra));
    return user || undefined;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values({
        ...insertUser,
        createdAt: new Date(),
        termsAcceptedAt: insertUser.termsAccepted ? new Date() : undefined,
      })
      .returning();
    return user;
  }

  async updateUser(id: number, updates: Partial<User>): Promise<User | undefined> {
    const [user] = await db
      .update(users)
      .set(updates)
      .where(eq(users.id, id))
      .returning();
    return user || undefined;
  }

  // Authentication operations
  async createSession(userId: number, ipAddress?: string, userAgent?: string): Promise<UserSession> {
    // Generate secure session token
    const sessionToken = crypto.randomBytes(32).toString('hex');
    
    // Set expiration to 1 week from now
    const expiresAt = new Date();
    expiresAt.setDate(expiresAt.getDate() + 7);

    const [session] = await db
      .insert(userSessions)
      .values({
        userId,
        sessionToken,
        expiresAt,
        createdAt: new Date(),
        ipAddress,
        userAgent,
      })
      .returning();

    return session;
  }

  async getValidSession(sessionToken: string): Promise<UserSession | undefined> {
    const [session] = await db
      .select()
      .from(userSessions)
      .where(
        and(
          eq(userSessions.sessionToken, sessionToken),
          gt(userSessions.expiresAt, new Date())
        )
      );
    
    return session || undefined;
  }

  async deleteSession(sessionToken: string): Promise<void> {
    await db
      .delete(userSessions)
      .where(eq(userSessions.sessionToken, sessionToken));
  }

  async deleteExpiredSessions(): Promise<void> {
    await db
      .delete(userSessions)
      .where(gt(new Date(), userSessions.expiresAt));
  }

  // Tool access logging
  async logToolAccess(userId: number, toolName: string, toolUrl: string, ipAddress?: string): Promise<ToolAccessLog> {
    const [log] = await db
      .insert(toolAccessLogs)
      .values({
        userId,
        toolName,
        toolUrl,
        accessedAt: new Date(),
        ipAddress,
      })
      .returning();

    return log;
  }

  async getUserToolAccess(userId: number, limit: number = 50): Promise<ToolAccessLog[]> {
    return await db
      .select()
      .from(toolAccessLogs)
      .where(eq(toolAccessLogs.userId, userId))
      .orderBy(toolAccessLogs.accessedAt)
      .limit(limit);
  }
}

// Memory storage fallback (for development/testing)
export class MemStorage implements IStorage {
  private users: Map<number, User> = new Map();
  private sessions: Map<string, UserSession> = new Map();
  private toolLogs: ToolAccessLog[] = [];
  private nextUserId = 1;
  private nextSessionId = 1;
  private nextLogId = 1;

  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByRA(ra: string): Promise<User | undefined> {
    for (const user of this.users.values()) {
      if (user.ra === ra) return user;
    }
    return undefined;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const user: User = {
      id: this.nextUserId++,
      ...insertUser,
      createdAt: new Date(),
      lastLoginAt: null,
      isActive: insertUser.isActive ?? true,
      termsAccepted: insertUser.termsAccepted ?? false,
      termsAcceptedAt: insertUser.termsAccepted ? new Date() : null,
    };
    this.users.set(user.id, user);
    return user;
  }

  async updateUser(id: number, updates: Partial<User>): Promise<User | undefined> {
    const user = this.users.get(id);
    if (!user) return undefined;
    
    const updatedUser = { ...user, ...updates };
    this.users.set(id, updatedUser);
    return updatedUser;
  }

  async createSession(userId: number, ipAddress?: string, userAgent?: string): Promise<UserSession> {
    const sessionToken = crypto.randomBytes(32).toString('hex');
    const expiresAt = new Date();
    expiresAt.setDate(expiresAt.getDate() + 7);

    const session: UserSession = {
      id: this.nextSessionId++,
      userId,
      sessionToken,
      expiresAt,
      createdAt: new Date(),
      ipAddress: ipAddress || null,
      userAgent: userAgent || null,
    };

    this.sessions.set(sessionToken, session);
    return session;
  }

  async getValidSession(sessionToken: string): Promise<UserSession | undefined> {
    const session = this.sessions.get(sessionToken);
    if (!session || session.expiresAt < new Date()) {
      this.sessions.delete(sessionToken);
      return undefined;
    }
    return session;
  }

  async deleteSession(sessionToken: string): Promise<void> {
    this.sessions.delete(sessionToken);
  }

  async deleteExpiredSessions(): Promise<void> {
    const now = new Date();
    for (const [token, session] of this.sessions.entries()) {
      if (session.expiresAt < now) {
        this.sessions.delete(token);
      }
    }
  }

  async logToolAccess(userId: number, toolName: string, toolUrl: string, ipAddress?: string): Promise<ToolAccessLog> {
    const log: ToolAccessLog = {
      id: this.nextLogId++,
      userId,
      toolName,
      toolUrl,
      accessedAt: new Date(),
      ipAddress: ipAddress || null,
    };

    this.toolLogs.push(log);
    return log;
  }

  async getUserToolAccess(userId: number, limit: number = 50): Promise<ToolAccessLog[]> {
    return this.toolLogs
      .filter(log => log.userId === userId)
      .sort((a, b) => b.accessedAt.getTime() - a.accessedAt.getTime())
      .slice(0, limit);
  }
}

// Create storage instance - use database if available, fallback to memory
export const storage: IStorage = (() => {
  try {
    // Try to create database storage
    return new DatabaseStorage();
  } catch (error) {
    console.warn('Database not available, using memory storage:', error);
    return new MemStorage();
  }
})();